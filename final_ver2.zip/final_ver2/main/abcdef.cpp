#include <SD.h>
#include <SPI.h>
#include "Arduino.h"
#include "abcdef.h"
#include <SoftwareSerial.h>
SoftwareSerial mySerial(2, 3); 
 
 int strlength;
 float funlength;
 float FL = floor(funlength);
 int buttonState = 0;
 
 int dataPin= 11;//23;
 int clockPin = 12;//38;
 int latchPin = 8;//39; 
 
 byte data[31] = 
 {
   0B10000000,//a
   0B11000000,//b
   0B10010000,//c
   0B10011000,//d
   0B10001000,//e
   0B11010000,//f
   0B11011000,//g
   0B11001000,//h
   0B01010000,//i
   0B01011000,//j
   0B10100000,//k
   0B11100000,//l
   0B10110000,//m
   0B10111000,//n
   0B10101000,//o
   0B11110000,//p
   0B11111000,//q
   0B11101000,//r
   0B01110000,//s
   0B01111000,//t
   0B10100100,//u
   0B11100100,//v
   0B01011100,//w
   0B10110100,//x
   0B10111100,//y
   0B10101100,//z
   0B01001100,//.
   0B01100100,//?
   0B01101000,//!
   0B00001000,//,
   0B00000000//space
 
 };
/////////////////////////////////////////////////////////
void forBT(){
  int btcheck = 0;
  int sendcheck = 0;
  
  Serial.begin(9600); 
  mySerial.begin(9600);
  delay(100);
  
      if(mySerial)
      {
        Serial.println(mySerial);
        Serial.println("connected Serial1");
        btcheck = 1;
      }
      else{
        Serial.println(mySerial);
        Serial.println("Non connected Serial1");
        }
        
    if(btcheck == 1){
      while(!sendcheck){        
        if(mySerial.available()){  // need check if to while?
          inputString = mySerial.readString();
          sendcheck = 1;
          }
        }
      delay(100);  
      
      } 
      mcrg();   
  }
/////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////
void readSD(){
  inputString = "";
  mySerial.begin(9600);
  File myFile;
  Serial.print("Initializing SD card...");  
        if (!SD.begin(53)) 
        {
            Serial.println("initialization failed!");
        }
        else{
          Serial.println("initialization done.");
        }
 
  myFile = SD.open("test.txt");
        if(myFile)
        {
        Serial.println("test.txt:");
        while(myFile.available())
        {
        char inChar = (char)myFile.read();
        inputString += inChar;
        
        } 
        myFile.close();
        }
  Serial.println(inputString);
  }
/////////////////////////////////////////////////////////
void saveSD(){
  mySerial.begin(9600);
  File myFile;
  Serial.print("Initializing SD card...");  
        if (!SD.begin(53)) 
        {
            Serial.println("initialization failed!");
        }
        else{
          Serial.println("initialization done.");
        }
        
                  SD.remove("test.txt");
                  delay(200);
                  myFile = SD.open("test.txt", FILE_WRITE);
                  while(1){
                    if(mySerial.available()){
                      String Cheeze;
                  Cheeze = mySerial.readString();
                  
                  Serial.println(Cheeze);
                    if(myFile)
                    {
                                 Serial.print("Writing to test.txt...");
                                 myFile.print(Cheeze);
                                 
                                 myFile.close();
                                 Serial.println("done.");
                                
                     }
                    else
                    {
                        Serial.println("error opening test.txt");
                    }
                    break;
                      
                      }
                  }
                
                Serial.println("saved String");
        myFile = SD.open("test.txt");
        
        if (myFile) {
                Serial.println("test.txt:");
                // test 파일의 내용을 시리얼 모니터에 출력한다.
                while (myFile.available()) { 
                Serial.write(myFile.read());
        }
        
        //파일을 닫아준다.
        myFile.close();
        
        } else {
                // 파일이 열리지 않았다면 오류 메시지를 출력
                Serial.println("error opening test.txt");
        }
       delay(4000);
  }
/////////////////////////////////////////////////////////

 void SDC()
        {
        mySerial.begin(9600);
        File myFile;
       
        Serial.print("Initializing SD card...");  
        if (!SD.begin(53)) 
        {
            Serial.println("initialization failed!");
        }
        Serial.println("initialization done.");
        Serial.println(mySerial.available());
        while(!mySerial.available())
        {
          if(Serial.read()=='a')
          {
                                  Serial.println("BTS No connected");
                                  break;
                                 }
        }
        while(mySerial.available())
        {
                if(Serial.read()=='b')
                {
                  SD.remove("test.txt");
                  myFile = SD.open("test.txt", FILE_WRITE);
                  String Cheeze;
                  Cheeze = mySerial.readString();
                  Serial.println(Cheeze);
                    if(myFile)
                    {
                                 Serial.print("Writing to test.txt...");
                                 myFile.print(Cheeze);
                                 delay(200);
                                 myFile.close();
                                 Serial.println("done.");
                                
                     }
                    else
                    {
                        Serial.println("error opening test.txt");
                    }
                    break;
                }

        }    
        myFile = SD.open("test.txt");
        if(myFile)
        {
        Serial.println("test.txt:");
        while(myFile.available())
        {
        char inChar = (char)myFile.read();
        inputString += inChar;
        Serial.write(inChar);
        } 
        myFile.close();
        }
        else
        {
        Serial.println("error opening test.txt");
        }
        Serial.print("\ninputString : ");
        Serial.println(inputString);
        strlength = inputString.length();
        funlength = strlength / 6;
        Serial.println(strlength);
        Serial.println(funlength);
}
/////////////////////////////////////////////////////////        
void mcrg()
{
      Serial.print("\ninputString : ");
      Serial.println(inputString);
      
      strlength = inputString.length();
      funlength = strlength / 1;
      Serial.println(strlength);
      Serial.println(funlength);
    int K = 0;  

  /*
  for (K; K <= funlength;)
  {
    */
    loop1:;
 {

  if(K <= funlength){
  
  Serial.print("K=");
  Serial.println(K);
  buttonState = 0;
  
      String mystring = inputString.substring(K * 1, (K + 1) * 1); //substring
      digitalWrite(latchPin, LOW);
      delay(200);
     for (int num = 0; num < 1; num++) // num
     {
        char ch = mystring[num];
        int yh=ch;
        if(yh>96 && yh<123)
        {
        Serial.println(ch);
        Serial.println(yh);
        shiftOut(dataPin,clockPin, LSBFIRST,data[yh-97]);
        }
        else
        {
          switch(yh)
          {
          case 46:
          Serial.println(ch);
          Serial.println(yh);
          shiftOut(dataPin,clockPin, LSBFIRST,data[26]);
          break;
          case 44:
          Serial.println(ch);
          Serial.println(yh);
          shiftOut(dataPin,clockPin, LSBFIRST,data[29]);
          break;
          case 63:
          Serial.println(ch);
          Serial.println(yh);
          shiftOut(dataPin,clockPin, LSBFIRST,data[27]);
          break; 
          case 33:
          Serial.println(ch);
          Serial.println(yh);
          shiftOut(dataPin,clockPin, LSBFIRST,data[28]);
          break;
          case 32:
          Serial.println(ch);
          Serial.println(yh);
          shiftOut(dataPin,clockPin, LSBFIRST,data[30]);
          break;
          
          }
           //delay(1000);
        }
     }
        delay(200);
        digitalWrite(latchPin, HIGH);
         ////////////////////////////////////////
             delay(500);
             K++;
             goto loop1; 
/////////////////////////////////////
 }
        }
  
  /*}*/
  }
  /////////////////////////////////////////////////////////        
