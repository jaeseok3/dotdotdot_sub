#ifndef abcdef_h

#define abcdef_h

extern String inputString;

extern int latchPin;

extern int dataPin;

extern int clockPin;

extern int stlength;

extern byte data[];

extern float funlength;

extern float FL;

extern int buttonstate;

extern int mcrg_button;

extern int BT_button;

extern int SDread_button;

extern int SDsave_button;

void SDC();

void mcrg();

void forBT();

void readSD();

void saveSD();

#endif
